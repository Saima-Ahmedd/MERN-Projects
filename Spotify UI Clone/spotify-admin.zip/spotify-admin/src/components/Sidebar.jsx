import React from 'react';
import { assets } from '../assets/assets';
import { NavLink } from 'react-router-dom';

const Sidebar = () => {
  return (
    <div className="bg-[#003A10] h-screen w-16 sm:w-60 flex flex-col items-center sm:items-end px-2 sm:pl-4 pt-6 shadow-md overflow-y-auto">

      {/* Logo */}
      <img
        src={assets.logo_small}
        alt="Spotify"
        className="w-8 sm:hidden mb-10"
      />
      <img
        src={assets.logo}
        alt="Spotify"
        className="hidden sm:block w-42 object-contain mb-10 self-end"
      />

      {/* Navigation */}
      <div className="flex flex-col items-end sm:items-start gap-6 w-full">

        <NavLink
          to="/add-song"
          className="flex items-center gap-2 text-black bg-white border border-black px-3 py-2 shadow-[4px_4px_0px_0px_#00FF5B] text-sm font-medium w-full sm:w-44 justify-center sm:justify-start"
        >
          <img src={assets.add_song} className="w-5" alt="Add Song" />
          <span className="hidden sm:inline">Add Song</span>
        </NavLink>

        <NavLink
          to="/list-song"
          className="flex items-center gap-2 text-black bg-white border border-black px-3 py-2 shadow-[4px_4px_0px_0px_#00FF5B] text-sm font-medium w-full sm:w-44 justify-center sm:justify-start"
        >
          <img src={assets.song_icon} className="w-5" alt="List Song" />
          <span className="hidden sm:inline">List Song</span>
        </NavLink>

        <NavLink
          to="/add-album"
          className="flex items-center gap-2 text-black bg-white border border-black px-3 py-2 shadow-[4px_4px_0px_0px_#00FF5B] text-sm font-medium w-full sm:w-44 justify-center sm:justify-start"
        >
          <img src={assets.add_album} className="w-5" alt="Add Album" />
          <span className="hidden sm:inline">Add Album</span>
        </NavLink>

        <NavLink
          to="/list-album"
          className="flex items-center gap-2 text-black bg-white border border-black px-3 py-2 shadow-[4px_4px_0px_0px_#00FF5B] text-sm font-medium w-full sm:w-44 justify-center sm:justify-start"
        >
          <img src={assets.album_icon} className="w-5" alt="List Album" />
          <span className="hidden sm:inline">List Album</span>
        </NavLink>

      </div>
    </div>
  );
};

export default Sidebar;
