import React from 'react';

const HomePage = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] text-center px-4">
        <h1 className="text-3xl sm:text-4xl font-bold text-green-700 mb-4">
            Welcome to the Admin Panel
        </h1>
        <p className="text-lg sm:text-xl text-gray-600">
            Select an option from the sidebar to get started.
        </p>
    </div>

  );
};

export default HomePage;
