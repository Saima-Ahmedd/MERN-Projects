import React, { useEffect } from 'react';
import axios from 'axios';
import { url } from '../App.jsx';
import { toast } from 'react-toastify';

const ListAlbum = () => {

  const [data, setData] = React.useState([]);

  const fetchAlbums = async () => {

    try {

      const response = await axios.get(`${url}/api/album/list`);

      console.log(response.data);

      if (response.data.success) {
        setData(response.data.albums);
      } else {
        console.error("Failed to fetch albums:", response.data.message);
      }

    } catch (error) {
      toast.error("An error occurred while fetching albums.");
    }
  }



  const removeAlbum = async (id) => {

    try {

      const response = await axios.delete(`${url}/api/album/remove/${id}`);


      console.log(response.data);

      if (response.data.success) {
        toast.success("Album deleted successfully!");
        await fetchAlbums(); // Refresh the song list after deletion
      } else {
        toast.error("Failed to delete album. Please try again.");
      }
      
    } catch (error) {
      toast.error("An error occurred while deleting the album.");
    }
  }


  useEffect(() => {
    fetchAlbums();
  },[])

  return (
    <div>
      <p>All Albums List</p>
      <br />

      <div>

        <div className="sm:grid hidden grid-cols-[0.5fr_1fr_2fr_1fr_0.5fr] items-center gap-2.5 p-3 border border-gray-300 text-sm mr-5 bg-gray-100">
          <b>Image</b>
          <b>Name</b>
          <b>Description</b>
          <b>Album Color</b>
          <b>Action</b>
        </div>

        {data.map((items, index) => {
          return(
            <div key={index} className="grid grid-cols-[0.5fr_1fr_2fr_1fr_0.5fr] items-center gap-2.5 p-3 border border-gray-300 text-sm mr-5">
              <img className='w-12' src={items.image} alt="" />
              <p>{items.name}</p>
              <p>{items.desc}</p>
              <input type="color" value={items.bgColor} disabled/>
              <p className='cursor-pointer' onClick={()=>removeAlbum(items._id)}>x</p>
            </div>
          )
        })}
      </div>

    </div>
  )
}

export default ListAlbum;
